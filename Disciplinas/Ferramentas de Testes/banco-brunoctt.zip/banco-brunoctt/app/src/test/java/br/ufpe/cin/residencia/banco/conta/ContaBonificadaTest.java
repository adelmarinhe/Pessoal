package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContaBonificadaTest {
    private ContaBonificada conta;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final int valor = 100;

    @BeforeEach
    void setUp(){
        conta = new ContaBonificada("000", leopoldo);
    }

    @Test
    void creditar() {
        conta.creditar(valor);
        assertEquals(
                valor,
                conta.getSaldo(),
                "O saldo da conta deveria ser o valor creditado"
        );
        assertEquals(
                valorDoBonus(valor),
                conta.getBonus(),
                "O bonus da conta deveria ter sido incrementado após operação de creditar"
        );
    }

    @Test
    void renderBonusInicial() {
        conta = new ContaBonificada("000", valor, leopoldo);
        conta.renderBonus();
        assertEquals(
                valor,
                conta.getSaldo(),
                "O saldo final deveria ser igual ao inicial, já que o bonus era zero"
        );
    }

    @Test
    void renderBonus(){
        conta.creditar(valor);
        conta.renderBonus();
        assertEquals(
                valor + valorDoBonus(valor),
                conta.getSaldo(),
                "O saldo da conta deveria ser o valor da conta mais o bonus"
        );
    }

    @Test
    void getBonusInicial() {
        assertEquals(
                0,
                conta.getBonus(),
                "O bonus inicial de uma conta deveria ser 0"
        );
    }

    double valorDoBonus(double valorCredito) {
        return valorCredito * 0.01;
    }
}
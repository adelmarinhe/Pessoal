package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.excecoes.ContaExistenteException;
import br.ufpe.cin.residencia.banco.excecoes.ContaInexistenteException;
import br.ufpe.cin.residencia.banco.excecoes.SaldoInsuficienteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CadastroContasTest {
    private CadastroContas cadastro;
    private RepositorioContasMap repositorio;
    private static final double saldoInicial = 100;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final Conta contaLeopoldo = new Conta("000", saldoInicial, leopoldo);
    private final Cliente marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);
    private final Conta contaMarcio = new Conta("111", saldoInicial, marcio);

    @BeforeEach
    void setUp() throws ContaExistenteException {
        repositorio = new RepositorioContasMap();
        cadastro = new CadastroContas(repositorio);
        cadastro.cadastrar(contaLeopoldo);
    }

    @Test
    void cadastrarNovaConta() {
        assertTrue(repositorio.existe(contaLeopoldo.getNumero()), "Conta deveria estar cadastrada no repositório");
    }

    @Test
    void cadastrarContaExistente() {
        assertThrows(
                ContaExistenteException.class,
                () -> cadastro.cadastrar(contaLeopoldo),
                "Cadastrar uma mesma conta deveria levantar erro"
        );
    }

    @Test
    void atualizarContaExistente() throws ContaInexistenteException {
        double novosaldo = 999;
        contaLeopoldo.setSaldo(novosaldo);
        cadastro.atualizar(contaLeopoldo);
        assertEquals(
                contaLeopoldo,
                cadastro.procurar(contaLeopoldo.getNumero()),
                "Conta retornada deveria ser igual à esperada"
        );
    }

    @Test
    void atualizarContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> cadastro.atualizar(contaMarcio),
                "Tentar atualizar conta não cadastrada deve levantar erro"
        );
    }

    @Test
    void procurarContaExistente() throws ContaInexistenteException {
        assertEquals(
                contaLeopoldo,
                cadastro.procurar(contaLeopoldo.getNumero()),
                "Conta de Leopoldo deveria ser retornada"
        );
    }

    @Test
    void procurarContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> cadastro.procurar(contaMarcio.getNumero()),
                "Buscar conta não cadastrada deve retornar erro"
        );
    }

    @Test
    void removerContaExistente() throws ContaInexistenteException {
        cadastro.remover(contaLeopoldo.getNumero());
        assertFalse(repositorio.existe(contaLeopoldo.getNumero()), "Conta não pode estar cadastrada");
    }

    @Test
    void removerContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> cadastro.remover(contaMarcio.getNumero()),
                "Tentativa de remover conta não cadastrada deve levantar erro"
        );
    }

    @Test
    void creditar() throws ContaInexistenteException {
        double valorCreditado = 200;
        cadastro.creditar(contaLeopoldo.getNumero(), valorCreditado);
        assertEquals(
                saldoInicial + valorCreditado,
                contaLeopoldo.getSaldo(),
                "O valor do saldo deveria ser igual à soma do inicial mais o valor creditado"
        );
    }

    @Test
    void debitarTendoSuficiente() throws SaldoInsuficienteException, ContaInexistenteException {
        cadastro.debitar(contaLeopoldo.getNumero(), saldoInicial);
        assertEquals(
                0,
                contaLeopoldo.getSaldo(),
                "Após debitar valor igual ao saldo inicial, conta deveria ficar com 0"
        );
    }

    @Test
    void debitarNaoTendoSuficiente() {
        assertThrows(
                SaldoInsuficienteException.class,
                () -> cadastro.debitar(contaLeopoldo.getNumero(), saldoInicial+1),
                "Debitar valor maior que o saldo da conta deveria levantar erro"
        );
    }

    @Test
    void transferirTendoSuficiente() throws SaldoInsuficienteException, ContaInexistenteException, ContaExistenteException {
        cadastro.cadastrar(contaMarcio);
        cadastro.transferir(contaLeopoldo.getNumero(), contaMarcio.getNumero(), saldoInicial);
        assertEquals(
                saldoInicial * 2,
                contaMarcio.getSaldo(),
                "O saldo da conta que recebeu o dinheiro deveria ser 2 vezes o saldo inicial"
        );
        assertEquals(
                0,
                contaLeopoldo.getSaldo(),
                "O saldo da conta que transferiu o dinheiro deveria estar zerado"
        );
    }

    @Test
    void transferirNaoTendoSuficiente() throws ContaExistenteException {
        cadastro.cadastrar(contaMarcio);
        assertThrows(
                SaldoInsuficienteException.class,
                () -> cadastro.transferir(contaLeopoldo.getNumero(), contaMarcio.getNumero(), saldoInicial+1),
                "Tentativa de transferir tendo valor acima do saldo deve levantar erro"
        );
    }
}
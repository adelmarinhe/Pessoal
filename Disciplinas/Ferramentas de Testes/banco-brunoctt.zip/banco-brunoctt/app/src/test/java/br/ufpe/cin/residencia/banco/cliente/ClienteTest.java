package br.ufpe.cin.residencia.banco.cliente;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClienteTest {
    private Cliente cliente;
    final private String cpfPadrao = "12345678900";
    final private String nomePadrao = "Leopoldo";
    final private TipoCliente tipoPadrao = TipoCliente.VIP;

    @BeforeEach
    void setUp(){
        cliente = new Cliente(cpfPadrao, nomePadrao, tipoPadrao);
    }

    @Test
    void getCpf() {
        assertEquals(cpfPadrao, cliente.getCpf(), "O CPF do cliente deveria ser o valor padrão");
    }

    @Test
    void getNome() {
        assertEquals(nomePadrao, cliente.getNome(), "O nome do cliente deveria ser o valor padrão");
    }

    @Test
    void getTipo() {
        assertEquals(tipoPadrao, cliente.getTipo(), "O tipo do cliente deveria ser o valor padrão");
    }

    @Test
    void setCpf() {
        String cpfDiferente = "12345678911";
        cliente.setCpf(cpfDiferente);
        assertEquals(cpfDiferente, cliente.getCpf(), "O CPF do cliente deveria ser o valor diferente após a mudança");
    }

    @Test
    void setNome() {
        String nomeDiferente = "Marcio";
        cliente.setNome(nomeDiferente);
        assertEquals(nomeDiferente, cliente.getNome(), "O nome do cliente deveria ser o valor diferente após a mudança");
    }

    @Test
    void setTipo() {
        TipoCliente tipoDiferente = TipoCliente.ESPECIAL;
        cliente.setTipo(tipoDiferente);
        assertEquals(tipoDiferente, cliente.getTipo(), "O tipo do cliente deveria ser o valor diferente após a mudança");
    }
}
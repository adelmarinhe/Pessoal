package br.ufpe.cin.residencia.banco.cliente;

import br.ufpe.cin.residencia.banco.excecoes.ClienteInexistenteException;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RepositorioClientesArrayTest {
    private static IRepositorioClientes repositorio;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final Cliente marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);

    @BeforeEach
    void setUp(){
        repositorio = new RepositorioClientesArray();
    }

    @Test
    void existeSemCliente(){
        assertFalse(
                repositorio.existe(marcio.getCpf()),
                "O repositório deveria estar vazio, e então não ter clientes"
        );
    }

    @Test
    void existeDoisClientes(){
        repositorio.inserir(leopoldo);
        repositorio.inserir(marcio);
        assertTrue(
                repositorio.existe(leopoldo.getCpf()),
                "O repositório deveria conter cliente Leopoldo"
        );
        assertTrue(
                repositorio.existe(marcio.getCpf()),
                "O repositório deveria conter cliente Marcio"
        );
    }

    @Test
    void inserirCliente() throws ClienteInexistenteException {
        repositorio.inserir(leopoldo);
        assertTrue(repositorio.existe(leopoldo.getCpf()));
        assertEquals(
                leopoldo,
                repositorio.procurar(leopoldo.getCpf()),
                "O método deveria retornar o cliente Leopoldo"
        );
    }

    @Test
    void inserirClienteExistente() {
        repositorio.inserir(leopoldo);
        repositorio.inserir(leopoldo);
        Cliente[] clientesEsperados = new Cliente[100];
        clientesEsperados[0] = leopoldo;
        assertEquals(
                Arrays.asList(clientesEsperados),
                repositorio.listar(),
                "Somente deveria existir um cliente Leopoldo"
        );
    }

    @Test
    void inserirAcimaCache(){
        double cpf = 12345678900D;
        for (int i = 0; i <= 100; i++){
            // Tentando inserir 101 clientes
            repositorio.inserir(new Cliente(String.valueOf(cpf+i), "Fulano", TipoCliente.VIP));
        }
        assertEquals(100, repositorio.listar().size(), "Por exceder o cache, deveriam ter apenas 100 clientes");
    }

    @Test
    void procurarClienteInexistenteVazio(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.procurar(leopoldo.getCpf()),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void procurarClienteInexistentePreenchido(){
        repositorio.inserir(marcio);
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.procurar(leopoldo.getCpf()),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void removerClienteExistente() throws ClienteInexistenteException {
        repositorio.inserir(leopoldo);
        repositorio.inserir(marcio);
        repositorio.remover(leopoldo.getCpf());
        assertFalse(
                repositorio.existe(leopoldo.getCpf()),
                "Como cliente foi removido, deveria retornar que não existe"
        );
        Cliente[] clientesEsperados = new Cliente[100];
        clientesEsperados[0] = marcio;
        assertEquals(
                Arrays.asList(clientesEsperados),
                repositorio.listar(),
                "O formato do array após remoção deve ser igual ao do esperado"
        );
    }

    @Test
    void removerClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.remover(marcio.getCpf()),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void atualizarClienteExistente() throws ClienteInexistenteException {
        repositorio.inserir(leopoldo);
        leopoldo.setNome("Melhor professor (pode ponto extra?)");
        repositorio.atualizar(leopoldo);
        assertEquals(leopoldo, repositorio.procurar(leopoldo.getCpf()), "Os clientes deveriam ser iguais");
    }

    @Test
    void atualizarClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.atualizar(leopoldo),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void listarClientesVazio(){
        assertEquals(
                Arrays.asList(new Cliente[100]),
                repositorio.listar(),
                "Nenhum cliente foi inserido, esperado vazio"
        );
    }

    @Test
    void listarClientes(){
        repositorio.inserir(leopoldo);
        repositorio.inserir(marcio);
        Cliente[] clientesEsperados = new Cliente[100];
        clientesEsperados[0] = leopoldo;
        clientesEsperados[1] = marcio;
        assertEquals(
                Arrays.asList(clientesEsperados),
                repositorio.listar(),
                "Esperado que liste os 2 clientes inseridos"
        );
    }
}

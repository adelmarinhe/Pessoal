package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContaEspecialTest {
    private ContaAbstrata conta;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private static final double saldoInicial = 100;
    private static final double chequeEspecial = 50;
    private static final String numeroInicial = "111";

    @Test
    void getSaldo() {
        conta = new ContaEspecial(numeroInicial, saldoInicial, leopoldo, chequeEspecial);
        assertEquals(
                saldoInicial + chequeEspecial,
                conta.getSaldo(),
                "O valor do saldo deveria ser igual ao saldo inicial mais o cheque especial da conta"
        );
    }

    @Test
    void getSaldoSemChequeEspecial(){
        conta = new ContaEspecial(numeroInicial, saldoInicial, leopoldo);
        assertEquals(
                saldoInicial,
                conta.getSaldo(),
                "O valor do saldo deveria ser igual ao saldo inicial da conta"
        );
    }

    @Test
    void getSaldoSemChequeEspecialNemSaldo(){
        conta = new ContaEspecial(numeroInicial, leopoldo);
        assertEquals(
                0,
                conta.getSaldo(),
                "O valor do saldo deveria ser 0"
        );
    }
}
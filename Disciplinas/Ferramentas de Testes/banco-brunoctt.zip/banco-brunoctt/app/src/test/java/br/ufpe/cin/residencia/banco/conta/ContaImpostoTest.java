package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.excecoes.SaldoInsuficienteException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContaImpostoTest {
    private ContaImposto conta;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private static final double saldoInicial = 1001;

    @Test
    void debitarSuficiente() throws SaldoInsuficienteException {
        conta = new ContaImposto("000", saldoInicial, leopoldo);
        // Testando valor de fronteira
        conta.debitar(saldoInicial-1);
        assertEquals(
                0,
                conta.getSaldo(),
                "A soma do valor debitado e do imposto deveria zerar o saldo da conta"
        );
    }

    @Test
    void debitarSemSaldo(){
        conta = new ContaImposto("000", leopoldo);
        assertThrows(
                SaldoInsuficienteException.class,
                () -> conta.debitar(1),
                "Para qualquer valor maior que 0 debitado, deve levantar erro"
        );
    }
}
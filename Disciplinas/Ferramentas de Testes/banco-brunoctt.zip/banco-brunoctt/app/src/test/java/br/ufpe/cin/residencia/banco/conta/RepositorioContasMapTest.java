package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.excecoes.ContaInexistenteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class RepositorioContasMapTest {
    private IRepositorioContas repositorio;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final Cliente marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);
    double saldoInicial = 100;
    private final Conta contaLeopoldo = new Conta("000", saldoInicial, leopoldo);
    private final Conta contaMarcio = new Conta("111", saldoInicial, marcio);

    @BeforeEach
    void setUp() {
        repositorio = new RepositorioContasMap();
    }

    @Test
    void existe(){
        repositorio.inserir(contaLeopoldo);
        assertTrue(
                repositorio.existe(contaLeopoldo.getNumero()),
                "A conta existente no repositório deveria ser igual à conta procurada"
        );
    }

    @Test
    void existeComContaDiferente() {
        repositorio.inserir(contaLeopoldo);
        assertFalse(
                repositorio.existe(contaMarcio.getNumero()),
                "A conta existente no repositório deveria ser diferente da conta procurada"
        );
    }

    @Test
    void existeSemConta(){
        assertFalse(
                repositorio.existe(contaMarcio.getNumero()),
                "Não deveriam existir contas em repositório vazio"
        );
    }

    @Test
    void inserirEProcurar() throws ContaInexistenteException {
        repositorio.inserir(contaLeopoldo);
        assertTrue(
                repositorio.existe(contaLeopoldo.getNumero())
        );
        assertEquals(
                contaLeopoldo,
                repositorio.procurar(contaLeopoldo.getNumero())
        );
    }

    @Test
    void procurarContaInexistente(){
        repositorio.inserir(contaLeopoldo);
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.procurar(contaMarcio.getNumero()),
                "Ao procurar por conta que não está no repositório, deveria levantar erro"
        );
    }


    @Test
    void removerContaExistente() throws ContaInexistenteException {
        repositorio.inserir(contaLeopoldo);
        repositorio.remover(contaLeopoldo.getNumero());
        assertFalse(repositorio.existe(contaLeopoldo.getNumero()), "Conta não deveria existir");
    }

    @Test
    void removerContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.remover(contaMarcio.getNumero()),
                "Erro deveria ser levantado caso conta não exista"
        );
    }

    @Test
    void atualizarContaExistente() throws ContaInexistenteException {
        repositorio.inserir(contaLeopoldo);
        double novoSaldo = 201923;
        contaLeopoldo.setSaldo(novoSaldo);
        repositorio.atualizar(contaLeopoldo);
        assertEquals(
                contaLeopoldo,
                repositorio.procurar(contaLeopoldo.getNumero()),
                "Conta retornada deveria ser igual à modificada"
        );
    }

    @Test
    void atualizarContaInexistente(){
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.atualizar(contaLeopoldo),
                "Deveria levantar erro ao atualizar conta não inserida"
        );
    }

    @Test
    void listarContasVazio() {
        assertEquals(new ArrayList<>(), repositorio.listar(), "Nenhuma conta foi inserida, esperado vazio");
    }

    @Test
    void listar() {
        repositorio.inserir(contaLeopoldo);
        repositorio.inserir(contaMarcio);
        ArrayList<Conta> listaEsperada = new ArrayList<>(Arrays.asList(contaLeopoldo, contaMarcio));
        assertEquals(listaEsperada, repositorio.listar(), "Esperado que liste as 2 contas inseridas");
    }
}
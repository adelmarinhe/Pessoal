package br.ufpe.cin.residencia.banco.cliente;

import br.ufpe.cin.residencia.banco.excecoes.ClienteInexistenteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class RepositorioClientesMapTest {
    private static IRepositorioClientes repositorio;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final Cliente marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);

    @BeforeEach
    void setUp(){
        repositorio = new RepositorioClientesMap();
    }

    @Test
    void existeSemCliente(){
        assertFalse(
                repositorio.existe(marcio.getCpf()),
                "O repositório deveria estar vazio, e então não ter clientes"
        );
    }

    @Test
    void inserirCliente() throws ClienteInexistenteException {
        repositorio.inserir(leopoldo);
        assertTrue(repositorio.existe(leopoldo.getCpf()));
        assertEquals(
                leopoldo,
                repositorio.procurar(leopoldo.getCpf()),
                "O método deveria retornar o cliente Leopoldo"
        );
    }

    @Test
    void procurarClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.procurar(leopoldo.getCpf()),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void removerClienteExistente() throws ClienteInexistenteException {
        repositorio.inserir(leopoldo);
        repositorio.remover(leopoldo.getCpf());
        assertFalse(
                repositorio.existe(leopoldo.getCpf()),
                "Como cliente foi removido, deveria retornar que não existe"
        );
    }

    @Test
    void removerClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.remover(marcio.getCpf()),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void atualizarClienteExistente() throws ClienteInexistenteException {
        repositorio.inserir(leopoldo);
        leopoldo.setNome("Melhor professor (pode ponto extra?)");
        repositorio.atualizar(leopoldo);
        assertEquals(leopoldo, repositorio.procurar(leopoldo.getCpf()), "Os clientes deveriam ser iguais");
    }

    @Test
    void atualizarClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> repositorio.atualizar(leopoldo),
                "Erro deveria ser levantado caso cliente não exista"
        );
    }

    @Test
    void listarClientesVazio(){
        assertEquals(new ArrayList<>(), repositorio.listar(), "Nenhum cliente foi inserido, esperado vazio");
    }

    @Test
    void listarClientes(){
        repositorio.inserir(leopoldo);
        repositorio.inserir(marcio);
        ArrayList<Cliente> listaEsperada = new ArrayList<>(Arrays.asList(leopoldo, marcio));
        assertEquals(listaEsperada, repositorio.listar(), "Esperado que liste os 2 clientes inseridos");
    }

}

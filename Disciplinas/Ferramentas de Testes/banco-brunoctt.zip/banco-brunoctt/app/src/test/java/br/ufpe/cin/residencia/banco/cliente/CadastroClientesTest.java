package br.ufpe.cin.residencia.banco.cliente;

import br.ufpe.cin.residencia.banco.excecoes.ClienteExistenteException;
import br.ufpe.cin.residencia.banco.excecoes.ClienteInexistenteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CadastroClientesTest {
    private CadastroClientes cadastro;
    private RepositorioClientesMap repositorio;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);

    @BeforeEach
    void setUp(){
        repositorio = new RepositorioClientesMap();
        cadastro = new CadastroClientes(repositorio);
    }

    @Test
    void cadastrarNovoCliente() throws ClienteExistenteException {
        cadastro.cadastrar(leopoldo);
        assertTrue(repositorio.existe(leopoldo.getCpf()), "Novo cliente deveria ser cadastrado com sucesso");
    }

    @Test
    void cadastrarClienteExistente() throws ClienteExistenteException {
        cadastro.cadastrar(leopoldo);
        assertThrows(
                ClienteExistenteException.class,
                () -> cadastro.cadastrar(leopoldo),
                "Tentativa de cadastro de cliente já existente deveria levantar erro"
        );
    }

    @Test
    void atualizarClienteExistente() throws ClienteExistenteException, ClienteInexistenteException {
        cadastro.cadastrar(leopoldo);
        Cliente clone = new Cliente(leopoldo.getCpf(), leopoldo.getNome(), leopoldo.getTipo());
        clone.setNome("Melhor professor (pode ponto extra?)");
        cadastro.atualizar(clone);
        assertEquals(clone.getNome(), repositorio.procurar(leopoldo.getCpf()).getNome(), "Os clientes deveriam ser iguais");
    }

    @Test
    void atualizarClienteInexistente() {
        assertThrows(
                ClienteInexistenteException.class,
                () -> cadastro.atualizar(leopoldo),
                "Tentativa de atualização de cliente não existente deveria levantar erro"
        );
    }

    @Test
    void procurarClienteExistente() throws ClienteExistenteException, ClienteInexistenteException {
        cadastro.cadastrar(leopoldo);
        assertEquals(
                leopoldo,
                cadastro.procurar(leopoldo.getCpf()),
                "O método deveria retornar o cliente Leopoldo"
        );
    }

    @Test
    void procurarClienteInexistente() {
        assertThrows(
                ClienteInexistenteException.class,
                () -> cadastro.procurar(leopoldo.getCpf()),
                "Procurar cliente inexistente deveria levantar erro"
        );
    }

    @Test
    void descadastrarClienteExistente() throws ClienteExistenteException, ClienteInexistenteException {
        cadastro.cadastrar(leopoldo);
        cadastro.descadastrar(leopoldo.getCpf());
        assertFalse(repositorio.existe(leopoldo.getCpf()), "Descadastrar o cliente deveria remove-lo");
    }

    @Test
    void descadastrarClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> cadastro.descadastrar(leopoldo.getCpf()),
                "Descadastrar cliente ainda não cadastrado deveria levantar erro"
        );
    }
}

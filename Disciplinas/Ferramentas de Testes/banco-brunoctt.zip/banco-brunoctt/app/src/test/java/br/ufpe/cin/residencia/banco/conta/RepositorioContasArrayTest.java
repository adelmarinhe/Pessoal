package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.excecoes.ContaInexistenteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class RepositorioContasArrayTest {
    private IRepositorioContas repositorio;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final Cliente marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);
    double saldoInicial = 100;
    private final Conta contaLeopoldo = new Conta("000", saldoInicial, leopoldo);
    private final Conta contaMarcio = new Conta("111", saldoInicial, marcio);

    @BeforeEach
    void setUp() {
        repositorio = new RepositorioContasArray();
    }

    @Test
    void existeSemConta() {
        assertFalse(
                repositorio.existe(contaLeopoldo.getNumero()),
                "O repositório deveria estar vazio, e então não ter contas"
        );
    }

    @Test
    void existeDoisClientes() {
        repositorio.inserir(contaLeopoldo);
        repositorio.inserir(contaMarcio);
        assertTrue(
                repositorio.existe(contaLeopoldo.getNumero()),
                "O repositório deveria conter conta de Leopoldo"
        );
        assertTrue(
                repositorio.existe(contaMarcio.getNumero()),
                "O repositório deveria conter conta de Marcio"
        );
    }

    @Test
    void inserirConta() throws ContaInexistenteException {
        repositorio.inserir(contaLeopoldo);
        assertTrue(repositorio.existe(contaLeopoldo.getNumero()));
        assertEquals(
                contaLeopoldo,
                repositorio.procurar(contaLeopoldo.getNumero()),
                "O método deveria retornar a conta de Leopoldo"
        );
    }

    @Test
    void inserirContaExistente() {
        repositorio.inserir(contaLeopoldo);
        repositorio.inserir(contaLeopoldo);
        Conta[] contasEsperadas = new Conta[100];
        contasEsperadas[0] = contaLeopoldo;
        assertEquals(
                Arrays.asList(contasEsperadas),
                repositorio.listar(),
                "Somente deveria existir uma conta de Leopoldo"
        );
    }

    @Test
    void inserirAcimaCache(){
        double num = 100;
        Conta[] contasEsperadas = new Conta[101];
        for (int i = 0; i <= 100; i++) {
            Conta conta = new Conta(String.valueOf(num + i), leopoldo);
            repositorio.inserir(conta);
            contasEsperadas[i] = conta;
        }
        assertEquals(
                Arrays.asList(Arrays.copyOfRange(contasEsperadas, 0, 100)),
                repositorio.listar(),
                "O método listar deveria retornar um array igual aos primeiros 100 elementos de contasEsperadas"
        );
        assertEquals(100, repositorio.listar().size(), "Deveria ter quantidade igual ao máximo");
    }

    @Test
    void procurarContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.procurar(contaLeopoldo.getNumero()),
                "Como nenhuma conta foi inserida, qualquer busca deveria levantar erro"
        );
    }

    @Test
    void procurarContaInexistentePreenchido() {
        repositorio.inserir(contaMarcio);
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.procurar(contaLeopoldo.getNumero()),
                "Buscando por conta diferente da inserida deve levantar erro"
        );
    }

    @Test
    void removerContaExistente() throws ContaInexistenteException {
        repositorio.inserir(contaMarcio);
        repositorio.inserir(contaLeopoldo);
        repositorio.remover(contaMarcio.getNumero());
        assertFalse(repositorio.existe(contaMarcio.getNumero()), "Conta removida não pode existir");
        Conta[] contasEsperadas = new Conta[100];
        contasEsperadas[0] = contaLeopoldo;
        assertEquals(
                Arrays.asList(contasEsperadas),
                repositorio.listar(),
                "O formato do array após remoção deve ser igual ao do esperado"
        );
    }

    @Test
    void removerContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.remover(contaMarcio.getNumero()),
                "Tentativa de remover conta não cadastrada deveria levantar erro"
        );
    }

    @Test
    void atualizarContaExistente() throws ContaInexistenteException {
        repositorio.inserir(contaMarcio);
        String novoNumero = "999";
        contaMarcio.setNumero(novoNumero);
        repositorio.atualizar(contaMarcio);
        assertEquals(contaMarcio, repositorio.procurar(novoNumero), "As contas deveriam ser iguais");
    }

    @Test
    void atualizarContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> repositorio.atualizar(contaMarcio),
                "Erro deveria ser levantado caso conta não exista"
        );
    }

    @Test
    void listarClientesVazio() {
        assertEquals(
                Arrays.asList(new Conta[100]),
                repositorio.listar(),
                "Nenhuma conta foi inserida, esperado vazio"
        );
    }

    @Test
    void listarClientes() {
        repositorio.inserir(contaLeopoldo);
        repositorio.inserir(contaMarcio);
        Conta[] contasEsperadas = new Conta[100];
        contasEsperadas[0] = contaLeopoldo;
        contasEsperadas[1] = contaMarcio;
        assertEquals(
                Arrays.asList(contasEsperadas),
                repositorio.listar(),
                "Esperado que liste as 2 contas inseridas"
        );
    }
}
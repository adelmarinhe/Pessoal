package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.excecoes.SaldoInsuficienteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContaTest {
    private ContaAbstrata conta;
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private final Cliente marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);
    private static final double saldoInicial = 100;
    private static final String numeroInicial = "111";

    @BeforeEach
    void setUp() {
        conta = new Conta(numeroInicial, saldoInicial, leopoldo);
    }

    @Test
    void getSaldo() {
        assertEquals(saldoInicial, conta.getSaldo(), "O valor do saldo deveria ser igual ao inicial");
    }

    @Test
    void getCliente() {
        assertEquals(leopoldo, conta.getCliente(), "O cliente retornado deveria ser leopoldo");
    }

    @Test
    void getNumero() {
        assertEquals(numeroInicial, conta.getNumero(), "O valor do numero deveria ser igual ao inicial");
    }

    @Test
    void setCliente() {
        conta.setCliente(marcio);
        assertEquals(marcio, conta.getCliente(), "O cliente retornado deveria ser marcio após a mudança");
    }

    @Test
    void setNumero() {
        String novoNumero = "000";
        conta.setNumero(novoNumero);
        assertEquals(novoNumero, conta.getNumero(), "O valor do numero deveria ser igual ao novo valor");
    }

    @Test
    void setSaldo() {
        double novoSaldo = 200;
        conta.setSaldo(novoSaldo);
        assertEquals(novoSaldo, conta.getSaldo(), "O valor do saldo deveria ser igual ao novo valor");
    }

    @Test
    void creditar() {
        double valorCreditado = 200;
        conta.creditar(valorCreditado);
        assertEquals(
                saldoInicial + valorCreditado,
                conta.getSaldo(),
                "O valor do saldo deveria ser igual à soma do inicial mais o valor creditado"
        );
    }

    @Test
    void debitarTendoSuficiente() throws SaldoInsuficienteException {
        conta.debitar(saldoInicial);
        assertEquals(
                0,
                conta.getSaldo(),
                "Após debitar valor igual ao saldo inicial, conta deveria ficar com 0"
        );
    }

    @Test
    void debitarNaoTendoSuficiente() {
        assertThrows(
                SaldoInsuficienteException.class,
                () -> conta.debitar(saldoInicial+1),
                "Debitar valor maior que o saldo da conta deveria levantar erro"
        );
    }

    @Test
    void transferirTendoSuficiente() throws SaldoInsuficienteException {
        Conta segundaConta = new Conta("000", saldoInicial, marcio);
        conta.transferir(segundaConta, 100);
        assertEquals(
                saldoInicial * 2,
                segundaConta.getSaldo(),
                "O saldo da conta que recebeu o dinheiro deveria ser 2 vezes o saldo inicial"
        );
        assertEquals(
                0,
                conta.getSaldo(),
                "O saldo da conta que transferiu o dinheiro deveria estar zerado"
        );
    }

    @Test
    void transferirNaoTendoSuficiente(){
        Conta segundaConta = new Conta("000", marcio);
        assertThrows(
                SaldoInsuficienteException.class,
                () -> segundaConta.transferir(conta, 100),
                "Tentativa de transferir tendo saldo zerado deveria levantar erro"
        );
    }
}
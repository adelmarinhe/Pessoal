package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class PoupancaTest {
    private final Cliente leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
    private Poupanca poupanca;

    @Test
    void renderJurosSemSaldo() {
        poupanca = new Poupanca("000", leopoldo);
        poupanca.renderJuros(1);
        assertEquals(
                0,
                poupanca.getSaldo(),
                "Se a poupanca tinha saldo 0, mesmo rendendo 100%, deveria continuar"
        );
    }

    @ParameterizedTest
    @ValueSource(doubles = {0.5, 1, 2, 3})
    void renderJuros(double taxa){
        int saldoInicial = 100;
        poupanca = new Poupanca("000", saldoInicial, leopoldo);
        poupanca.renderJuros(taxa);
        assertEquals(
                saldoInicial * (1 + taxa),
                poupanca.getSaldo(),
                "Para um rendimento de 100%, a saldo final deveria ser 2 vezes o inicial"
        );

    }
}
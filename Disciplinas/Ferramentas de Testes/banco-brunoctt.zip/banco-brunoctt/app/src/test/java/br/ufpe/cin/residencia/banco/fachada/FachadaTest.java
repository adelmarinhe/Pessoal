package br.ufpe.cin.residencia.banco.fachada;

import java.lang.reflect.Field;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.conta.Conta;
import br.ufpe.cin.residencia.banco.excecoes.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FachadaTest {

    private Fachada fachada;
    private Cliente leopoldo;
    private Conta contaLeopoldo;
    private Cliente marcio;
    private Conta contaMarcio;

    @BeforeEach
    void setUp() {
        fachada = Fachada.obterInstancia();
        leopoldo = new Cliente("12345678900", "Leopoldo", TipoCliente.VIP);
        contaLeopoldo = new Conta("000", leopoldo);
        marcio = new Cliente("12345678911", "Marcio", TipoCliente.ESPECIAL);
        contaMarcio = new Conta("111", marcio);
    }

    @AfterEach
    void tearDown() {
        try {
            Field instance = Fachada.class.getDeclaredField("instancia");
            instance.setAccessible(true);
            instance.set(null, null);
            fachada = null;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @Test
	public void obterInstanciaFachada() {
		Fachada f2 = Fachada.obterInstancia();
		assertEquals(fachada,f2);
	}

    @Test
    void cadastrarCliente() throws ClienteExistenteException, ClienteInexistenteException {
        fachada.cadastrar(leopoldo);
        assertEquals(
                leopoldo,
                fachada.procurarCliente(leopoldo.getCpf()),
                "Objeto de cliente retornado deve ser igual ao cadastrado"
        );
    }

    @Test
    void cadastrarConta() throws ContaExistenteException, ClienteInvalidoException, ContaInexistenteException, ClienteExistenteException {
        fachada.cadastrar(leopoldo);
        fachada.cadastrar(contaLeopoldo);
        assertEquals(
                contaLeopoldo,
                fachada.procurarConta(contaLeopoldo.getNumero()),
                "Objeto de conta retornado deve ser igual ao cadastrado"
        );
    }

    @Test
    void cadastrarContaClienteNaoCadastrado(){
        assertThrows(
                ClienteInvalidoException.class,
                () -> fachada.cadastrar(contaMarcio),
                "Tentar cadastrar conta de um cliente não cadastrado deve levantar erro"
        );
    }

    @Test
    void atualizarCliente() throws ClienteExistenteException, ClienteInexistenteException {
        fachada.cadastrar(leopoldo);
        leopoldo.setNome("melhor que henrique");
        fachada.atualizar(leopoldo);
        assertEquals(
                leopoldo,
                fachada.procurarCliente(leopoldo.getCpf())
        );
    }

    @Test
    void atualizarClienteInexistente(){
        assertThrows(
                ClienteInexistenteException.class,
                () -> fachada.atualizar(leopoldo)
        );
    }

    @Test
    void atualizarConta() throws ContaExistenteException, ClienteInvalidoException, ContaInexistenteException, ClienteExistenteException {
        fachada.cadastrar(leopoldo);
        fachada.cadastrar(contaLeopoldo);
        contaLeopoldo.setNumero("9087358253847");
        fachada.atualizar(contaLeopoldo);
        assertEquals(
                contaLeopoldo,
                fachada.procurarConta(contaLeopoldo.getNumero())
        );
    }

    @Test
    void atualizarContaInexistente() {
        assertThrows(
                ContaInexistenteException.class,
                () -> fachada.atualizar(contaLeopoldo)
        );
    }

    @Test
    void descadastrarCliente() throws ClienteExistenteException, ClienteInexistenteException {
        fachada.cadastrar(leopoldo);
        fachada.descadastrarCliente(leopoldo.getCpf());
        assertThrows(
                ClienteInexistenteException.class,
                () -> fachada.procurarCliente(leopoldo.getCpf()),
                "Buscar cliente após descadastrar deve levantar erro"
        );
    }

    @Test
    void descadastrarConta() throws ClienteExistenteException, ContaExistenteException, ClienteInvalidoException, ContaInexistenteException {
        fachada.cadastrar(leopoldo);
        fachada.cadastrar(contaLeopoldo);
        fachada.descadastrarConta(contaLeopoldo.getNumero());
        assertThrows(
                ContaInexistenteException.class,
                () -> fachada.procurarConta(contaLeopoldo.getNumero()),
                "Buscar conta após descadastrar deve levantar erro"
        );
    }

    @Test
    void creditar() throws ClienteExistenteException, ContaExistenteException, ClienteInvalidoException, ContaInexistenteException {
        double valorCreditado = 100;
        fachada.cadastrar(leopoldo);
        fachada.cadastrar(contaLeopoldo);
        fachada.creditar(contaLeopoldo.getNumero(), valorCreditado);
        assertEquals(
                valorCreditado,
                contaLeopoldo.getSaldo(),
                "Conta com saldo inicial 0 deve apresentar igual a valor creditado"
        );
    }

    @Test
    void debitar() throws ClienteExistenteException, ContaExistenteException, ClienteInvalidoException, SaldoInsuficienteException, ContaInexistenteException {
        double valor = 100;
        fachada.cadastrar(leopoldo);
        fachada.cadastrar(contaLeopoldo);
        contaLeopoldo.creditar(valor);
        fachada.debitar(contaLeopoldo.getNumero(), valor);
        assertEquals(
                0,
                contaLeopoldo.getSaldo()
        );
    }

    @Test
    void transferir() throws ClienteExistenteException, ContaExistenteException, ClienteInvalidoException, SaldoInsuficienteException, ContaInexistenteException {
        double valor = 100;
        fachada.cadastrar(leopoldo);
        fachada.cadastrar(contaLeopoldo);
        fachada.cadastrar(marcio);
        fachada.cadastrar(contaMarcio);
        contaLeopoldo.creditar(valor);
        fachada.transferir(contaLeopoldo.getNumero(), contaMarcio.getNumero(), valor);
        assertEquals(0, contaLeopoldo.getSaldo());
        assertEquals(valor, contaMarcio.getSaldo());
    }
}
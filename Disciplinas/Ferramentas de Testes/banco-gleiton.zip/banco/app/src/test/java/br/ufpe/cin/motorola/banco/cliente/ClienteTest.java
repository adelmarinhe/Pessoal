package br.ufpe.cin.motorola.banco.cliente;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClienteTest {

    @Test
    void getCpf() {
    }

    @Test
    void getNome() {
    }

    @Test
    void getTipo() {
    }

    @Test
    void setCpf() {
    }

    @Test
    void setNome() {
    }

    @Test
    void setTipo() {
    }
}
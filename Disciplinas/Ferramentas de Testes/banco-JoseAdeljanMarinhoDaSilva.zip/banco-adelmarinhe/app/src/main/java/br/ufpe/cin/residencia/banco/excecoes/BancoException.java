package br.ufpe.cin.residencia.banco.excecoes;

public class BancoException extends Exception {
	public BancoException(String msg) {
		super(msg);
	}
}

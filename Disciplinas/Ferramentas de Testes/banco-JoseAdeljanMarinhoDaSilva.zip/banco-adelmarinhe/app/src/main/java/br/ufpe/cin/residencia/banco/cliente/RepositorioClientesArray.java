package br.ufpe.cin.residencia.banco.cliente;

import br.ufpe.cin.residencia.banco.excecoes.ClienteInexistenteException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RepositorioClientesArray implements IRepositorioClientes {
	private Cliente[] clientes;
	private int indice;

	private final static int tamCache = 100;

	public RepositorioClientesArray() {
		indice = 0;
		clientes = new Cliente[tamCache];
	}

	@Override
	public void atualizar(Cliente c) throws ClienteInexistenteException {
		int i = procurarIndice(c.getCpf());
		if (i == -1) {
			throw new ClienteInexistenteException();
		}
		clientes[i] = c;
	}


	@Override
	public boolean existe(String cpf) {
		return procurarIndice(cpf) != -1;
	}

	@Override
	public void inserir(Cliente c) {
		clientes[indice] = c;
		indice = indice + 1;
	}

	@Override
	public Cliente procurar(String cpf) throws ClienteInexistenteException {
		int index = procurarIndice(cpf);
		if (index != -1) {
			return clientes[index];
		} else {
			throw new ClienteInexistenteException();
		}
	}


	private int procurarIndice(String cpf) {
		for (int i = 0; i < indice; i++) {
			if (clientes[i].getCpf().equals(cpf)) {
				return i;
			}
		}
		return -1;
	}


	@Override
	public void remover(String cpf) throws ClienteInexistenteException {
		if (existe(cpf)) {
			int i = this.procurarIndice(cpf);
			clientes[i] = clientes[indice - 1];
			clientes[indice - 1] = null;
			indice = indice - 1;
		} else {
			throw new ClienteInexistenteException();
		}
	}

	@Override
	public List<Cliente> listar() {
		return new ArrayList<>(Arrays.asList(clientes).subList(0, indice));
	}
}
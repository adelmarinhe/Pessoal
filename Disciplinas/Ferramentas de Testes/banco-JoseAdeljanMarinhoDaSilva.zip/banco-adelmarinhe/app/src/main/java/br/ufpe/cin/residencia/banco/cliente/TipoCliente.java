package br.ufpe.cin.residencia.banco.cliente;

public enum TipoCliente {
	VIP,
	CLASS,
	ESPECIAL;
}

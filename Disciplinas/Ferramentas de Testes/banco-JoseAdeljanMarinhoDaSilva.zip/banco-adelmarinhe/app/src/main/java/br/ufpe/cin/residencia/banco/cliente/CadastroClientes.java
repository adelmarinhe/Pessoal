package br.ufpe.cin.residencia.banco.cliente;

import br.ufpe.cin.residencia.banco.excecoes.ClienteExistenteException;
import br.ufpe.cin.residencia.banco.excecoes.ClienteInexistenteException;

public class CadastroClientes {
	private final IRepositorioClientes clientes;

	public CadastroClientes(IRepositorioClientes rep) {
		this.clientes = rep;
	}

	public void atualizar(Cliente c) throws ClienteInexistenteException {
		clientes.atualizar(c);
	}

	public void cadastrar(Cliente c) throws ClienteExistenteException {
		String cpf = c.getCpf();
		if (clientes.existe(cpf)) {
			throw new ClienteExistenteException();
		} else {
			clientes.inserir(c);
		}
	}

	public void descadastrar(String cpf) throws ClienteInexistenteException {
		clientes.remover(cpf);
	}

	public Cliente procurar(String cpf) throws ClienteInexistenteException {
		return clientes.procurar(cpf);
	}
}
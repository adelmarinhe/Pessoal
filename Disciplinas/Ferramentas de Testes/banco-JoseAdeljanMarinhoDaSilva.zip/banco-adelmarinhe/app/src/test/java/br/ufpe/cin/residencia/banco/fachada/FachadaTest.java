package br.ufpe.cin.residencia.banco.fachada;

import java.lang.reflect.Field;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.conta.Conta;
import br.ufpe.cin.residencia.banco.conta.ContaAbstrata;
import br.ufpe.cin.residencia.banco.excecoes.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FachadaTest {
    Fachada fachada;
    Cliente clienteUm;
    Cliente clienteDois;
    Conta contaUm;
    Conta contaDois;
    Cliente clienteQuatro;

    @BeforeEach
    void setUp() {
        fachada = Fachada.obterInstancia();
        clienteUm = new Cliente("00011122233", "Adel", TipoCliente.CLASS);
        clienteDois = new Cliente("00022244466", "Bruno", TipoCliente.VIP);
        clienteQuatro = new Cliente("00044488812", "Leopoldo", TipoCliente.VIP);

        contaUm = new Conta("00001", 1000, clienteUm);
        contaDois = new Conta("00002", 500, clienteDois);

        fachada = Fachada.obterInstancia();
    }

    @AfterEach
    void tearDown() {
        try {
            Field instance = Fachada.class.getDeclaredField("instancia");
            instance.setAccessible(true);
            instance.set(null, null);
            fachada = null;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testObterInstancia() {
        Fachada fachada = Fachada.obterInstancia();
        assertNotNull(fachada);
    }

    @Test
    void testAtualizarCliente() {
        try {
            Cliente clienteNovo = new Cliente("01234567890", "Jesus", TipoCliente.ESPECIAL);
            fachada.cadastrar(clienteNovo);
            fachada.atualizar(clienteNovo);
            assertDoesNotThrow(() -> fachada.atualizar(clienteNovo));

            assertThrows(ClienteInexistenteException.class, () -> fachada.atualizar(clienteQuatro));
//
            Cliente clienteTres = new Cliente("12345665432", "Lucas", TipoCliente.CLASS);
            assertThrows(ClienteInexistenteException.class, () -> fachada.atualizar(clienteTres));
        } catch (Exception e) {
            System.out.println("Error Test 1: " + e.getMessage());
        }
    }

    @Test
    void testProcurarCliente() {
        try {
            fachada.cadastrar(clienteUm);
            String cpfClienteUm = clienteUm.getCpf();
            Cliente clienteNovo = fachada.procurarCliente(cpfClienteUm);
            assertEquals(cpfClienteUm, clienteNovo.getCpf());

            assertThrows(ClienteInexistenteException.class, () -> fachada.procurarCliente("1234123412"));

            assertThrows(ClienteInexistenteException.class, () -> fachada.procurarCliente(null));

            assertDoesNotThrow(() -> fachada.procurarCliente(clienteUm.getCpf()));

            Cliente clienteTres = new Cliente(null, "João", TipoCliente.CLASS);
            assertThrows(ClienteInexistenteException.class, () -> fachada.procurarCliente(clienteTres.getCpf()));

            assertThrows(ClienteInexistenteException.class, () -> fachada.procurarCliente("12345678901"));
        } catch (Exception e) {
            System.out.println("Error Test 2: " + e.getMessage());
        }
    }

    @Test
    void testCadastrarCliente() {
        try {
            Cliente clienteInexistente = new Cliente(null, null, TipoCliente.CLASS);
            assertThrows(ClienteInexistenteException.class, () -> fachada.cadastrar(clienteInexistente));

            assertDoesNotThrow(() -> fachada.cadastrar(clienteUm));
            Cliente clienteTres = clienteUm;

            assertThrows(ClienteExistenteException.class, () -> fachada.cadastrar(clienteTres));
        } catch (Exception e) {
            System.out.println("Error Test 3: " + e.getMessage());
        }
    }

    @Test
    void testDescadastrarCliente() {
        try {
            fachada.cadastrar(clienteUm);
            Cliente clienteNovo = fachada.procurarCliente(clienteUm.getCpf());
            assertEquals("Adel", clienteNovo.getNome());
            fachada.descadastrarCliente(clienteNovo.getCpf());

            assertThrows(ClienteInexistenteException.class, () -> fachada.procurarCliente(clienteNovo.getCpf()));

            assertThrows(ClienteInexistenteException.class, () -> fachada.descadastrarCliente(null));

            assertThrows(ClienteInexistenteException.class, () -> fachada.descadastrarCliente(clienteDois.getCpf()));
        } catch (Exception e) {
            System.out.println("Error Test 4: " + e.getMessage());
        }
    }

    @Test
    void testAtualizarConta() {
        try {
            fachada.cadastrar(clienteUm);
            fachada.cadastrar(contaUm);
            assertDoesNotThrow(() -> fachada.atualizar(contaUm));
            ContaAbstrata contaAbs = fachada.procurarConta(contaUm.getNumero());
            assertEquals("Adel", contaAbs.getCliente().getNome());

            Conta contaNovaTeste = new Conta("0001", clienteDois);
            assertThrows(ContaInexistenteException.class, () -> fachada.atualizar(contaNovaTeste));

            contaAbs.getCliente().setNome("Larissa");

            assertDoesNotThrow(() -> fachada.atualizar(contaAbs));

            ContaAbstrata contaNova = fachada.procurarConta(contaUm.getNumero());
            assertEquals("Larissa", contaNova.getCliente().getNome());

        } catch (Exception e) {
            System.out.println("Error Test 5: " + e.getMessage());
        }
    }

    @Test
    void testProcurarConta() {
        try {
            fachada.cadastrar(clienteUm);
            fachada.cadastrar(contaUm);
            ContaAbstrata conta = fachada.procurarConta(contaUm.getNumero());
            assertEquals("Adel", conta.getCliente().getNome());

            Conta contaTres = new Conta("0003", 1000, clienteQuatro);
            assertThrows(ContaInexistenteException.class, () -> fachada.procurarConta(contaTres.getNumero()));
        } catch (Exception e) {
            System.out.println("Error Test 6: " + e.getMessage());
        }
    }

    @Test
    void testCadastrarConta() {
        try {
            fachada.cadastrar(clienteUm);
            assertDoesNotThrow(() -> fachada.cadastrar(contaUm));
            assertNotNull(fachada.procurarConta(contaUm.getNumero()));
            assertThrows(ContaExistenteException.class, () -> fachada.cadastrar(contaUm));

            fachada.cadastrar(clienteDois);
            assertDoesNotThrow(() -> fachada.cadastrar(contaDois));

            assertNotNull(fachada.procurarConta(contaDois.getNumero()));

            ContaAbstrata contaAbs = new ContaAbstrata("0001", null);
            assertThrows(ClienteInexistenteException.class, () -> fachada.cadastrar(contaAbs));
        } catch (Exception e) {
            System.out.println("Error Test 7: " + e.getMessage());
        }
    }

    @Test
    void testCreditar() {
        try {
            fachada.cadastrar(clienteUm);
            fachada.cadastrar(contaUm);
            ContaAbstrata contaAbstrata = fachada.procurarConta(contaUm.getNumero());
            assertEquals(1000, contaAbstrata.getSaldo());

            fachada.creditar(contaUm.getNumero(), 100);
            assertEquals(1100, contaUm.getSaldo());

            ContaAbstrata contaNova = fachada.procurarConta(contaUm.getNumero());
            assertEquals(1100, contaNova.getSaldo());

            assertThrows(ContaInexistenteException.class, () -> fachada.creditar(contaDois.getNumero(), 100));
        } catch (Exception e) {
            System.out.println("Error Test 8: " + e.getMessage());
        }
    }

    @Test
    void testDebitar() {
        try {
            fachada.cadastrar(clienteUm);
            fachada.cadastrar(contaUm);

            ContaAbstrata contaAbstrata = fachada.procurarConta(contaUm.getNumero());

            assertEquals(1000, contaAbstrata.getSaldo());

            fachada.debitar(contaUm.getNumero(), 100);
            assertEquals(900, contaUm.getSaldo());

            ContaAbstrata contaNova = fachada.procurarConta(contaUm.getNumero());
            assertEquals(900, contaNova.getSaldo());

            fachada.cadastrar(clienteDois);

            Conta contaTres = new Conta("0006",100, clienteUm);
            fachada.cadastrar(contaTres);
            assertThrows(SaldoInsuficienteException.class, () -> fachada.debitar("0006", 200));
        } catch (Exception e) {
            System.out.println("Error Test 9: " + e.getMessage());
        }
    }

    @Test
    void testDescadastrarConta() {
        try {
            fachada.cadastrar(clienteUm);
            fachada.cadastrar(contaUm);
            fachada.descadastrarConta(contaUm.getNumero());

            assertThrows(ContaInexistenteException.class, () -> fachada.procurarConta(contaUm.getNumero()));

            assertThrows(ContaInexistenteException.class, () -> fachada.descadastrarConta(contaDois.getNumero()));
        } catch (Exception e) {
            System.out.println("Error Test 10: " + e.getMessage());
        }
    }

    @Test
    void testTransferir() {
        try {
            fachada.cadastrar(clienteUm);
            fachada.cadastrar(clienteDois);
            fachada.cadastrar(contaUm);
            fachada.cadastrar(contaDois);
            fachada.transferir(contaUm.getNumero(), contaDois.getNumero(), 500);

            assertEquals(1000, contaDois.getSaldo());

            assertThrows(SaldoInsuficienteException.class, () -> fachada.transferir(contaUm.getNumero(), contaDois.getNumero(), 2 * contaUm.getSaldo()));

            Conta contaTres = new Conta("0009", 1500, clienteUm);
            assertThrows(ContaInexistenteException.class, () -> fachada.transferir(contaTres.getNumero(), contaDois.getNumero(), contaTres.getSaldo()));
        } catch (Exception e) {
            System.out.println("Error Test 11: " + e.getMessage());
        }
    }

    @Test
    void testCadastrarContaMutante() {
        try {
            ContaAbstrata contaComClienteNulo = new ContaAbstrata("00001", null);
            assertThrows(ClienteInexistenteException.class, () -> fachada.cadastrar(contaComClienteNulo));

            fachada.cadastrar(clienteUm);
            assertDoesNotThrow(() -> fachada.cadastrar(contaUm));
        } catch (Exception e) {
            System.out.println("ErrorTest 12: " + e.getMessage());
        }
    }

    @Test
    void testCadastrarClienteMutante() {
        try {
            Cliente clienteComCpfNulo = new Cliente(null, "João", TipoCliente.CLASS);
            assertThrows(ClienteInexistenteException.class, () -> fachada.cadastrar(clienteComCpfNulo));

            fachada.cadastrar(clienteUm);
            assertThrows(ClienteExistenteException.class, () -> fachada.cadastrar(clienteUm));
        } catch (Exception e) {
            System.out.println("Error Test 13: " + e.getMessage());
        }
    }

    @Test
    void testProcurarClienteMutante() {
        try {
            fachada.cadastrar(clienteUm);
            String cpfClienteUm = clienteUm.getCpf();
            Cliente clienteEncontrado = fachada.procurarCliente(cpfClienteUm);
            assertNotNull(clienteEncontrado);
            assertEquals(cpfClienteUm, clienteEncontrado.getCpf());
        } catch (Exception e) {
            System.out.println("Error Test 14: " + e.getMessage());
        }
    }

    @Test
    public void testInitCadastros() {
        assertNotNull(fachada.contas);
        assertNotNull(fachada.clientes);
    }



}
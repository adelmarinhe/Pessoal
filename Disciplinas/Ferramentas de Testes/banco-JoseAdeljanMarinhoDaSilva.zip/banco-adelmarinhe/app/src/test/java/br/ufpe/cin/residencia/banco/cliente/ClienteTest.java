package br.ufpe.cin.residencia.banco.cliente;

import static org.junit.jupiter.api.Assertions.*;

import br.ufpe.cin.residencia.banco.excecoes.ClienteInexistenteException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.util.Arrays;
import java.util.List;

class ClienteTest {

    RepositorioClientesMap RCMap;
    RepositorioClientesArray RCArray;
    Cliente clienteUm;
    Cliente clienteDois;
    Cliente clienteTres;
    Cliente[] clientes;

    @BeforeEach
    void setUp(){
        clienteUm = new Cliente("12345612345", "Adel", TipoCliente.CLASS);
        clienteDois = new Cliente("09876543212", "Bruno", TipoCliente.ESPECIAL);
        clienteTres = new Cliente("98765445678", "Leopoldo", TipoCliente.VIP);

        clientes = new Cliente[]{clienteUm, clienteDois, clienteTres};

        RCMap = new RepositorioClientesMap();
        RCMap.inserir(clienteUm);
        RCArray = new RepositorioClientesArray();
        RCArray.inserir(clienteUm);
    }

    @Test
    void atualizarMap() throws ClienteInexistenteException {
        RCMap.atualizar(clienteUm);
        Cliente clienteNovo = RCMap.procurar(clienteUm.getCpf());
        RCMap.inserir(clienteNovo);
        assertEquals("Adel", clienteNovo.getNome());

        clienteNovo.setNome("Bruno");
        RCMap.atualizar(clienteNovo);

        Cliente clienteNovoDois = RCMap.procurar("12345612345");
        assertEquals("Bruno", clienteNovoDois.getNome());
    }

    @Test
    void getCpf() {
        assertFalse(clienteUm.getCpf().isEmpty());
    }

    @Test
    void atualizarCliNullMap() {
        Cliente clienteNovo = new Cliente("12345678900", "João", TipoCliente.VIP);
        assertThrows(ClienteInexistenteException.class, () -> RCMap.atualizar(clienteNovo));

        assertDoesNotThrow(() -> RCMap.inserir(clienteNovo));
    }

    @Test
    void removerMap() throws ClienteInexistenteException {
        Cliente cliente = RCMap.procurar(clienteUm.getCpf());
        assertEquals("Adel", cliente.getNome());

        assertDoesNotThrow(() -> RCMap.remover(clienteUm.getCpf()));

        assertThrows(ClienteInexistenteException.class, () -> RCMap.procurar("12345612345"));
    }

    @Test
    void removerCliNullMap() {
        assertThrows(ClienteInexistenteException.class, () -> RCMap.remover("4345434352456"));
    }

    @Test
    void getNome() {
        assertFalse(clienteUm.getNome().isEmpty());
    }

    @Test
    void getTipo() {
        assertEquals(TipoCliente.CLASS, clienteUm.getTipo());

        assertEquals(TipoCliente.ESPECIAL, clienteDois.getTipo());

        assertEquals(TipoCliente.VIP, clienteTres.getTipo());
    }

    @Test
    void setCpf() {
        clienteUm.setCpf("00987654321");
        assertEquals("00987654321", clienteUm.getCpf());
    }

    @Test
    void setNome() {
        clienteUm.setNome("Bruno");
        assertEquals("Bruno", clienteUm.getNome());
    }

    @Test
    void setTipo() {
        clienteUm.setTipo(TipoCliente.VIP);
        assertEquals(TipoCliente.VIP, clienteUm.getTipo());
    }

    @Test
    void atualizarClienteInexistente() {
        Cliente clienteInexistente = new Cliente("98765432100", "Inexistente", TipoCliente.CLASS);
        assertThrows(ClienteInexistenteException.class, () -> {
            RCMap.atualizar(clienteInexistente);
        });
    }

    @Test
    public void testeCadastrarClientes() {
        assertDoesNotThrow(() -> RCMap.atualizar(clienteUm));
        assertThrows(ClienteInexistenteException.class, () -> RCMap.atualizar(clienteDois));
    }

    @Test
    void testListar() {
        try{
            List<Cliente> clientesMap = RCMap.listar();
            assertTrue(clientesMap.isEmpty());

            RCMap.atualizar(clienteUm);
            RCMap.atualizar(clienteDois);
            RCMap.atualizar(clienteTres);
            RCMap.inserir(clienteUm);
            RCMap.inserir(clienteDois);
            RCMap.inserir(clienteTres);

            assertEquals(List.of(clientesMap), RCMap.listar());

            assertEquals(0, RCMap.listar().size());
            assertEquals(100, RCArray.listar().size());

            List<Cliente> clientesArray = RCArray.listar();
            assertTrue(clientesArray.isEmpty());

            RCArray.inserir(clienteUm);
            RCArray.inserir(clienteDois);

            assertNotEquals(List.of(clientesMap), RCArray.listar().isEmpty());
            assertEquals(List.of(clientesMap), RCArray.listar());
            assertEquals(2, clientesArray.size());
            assertTrue(clientesArray.contains(clienteUm));
            assertTrue(clientesArray.contains(clienteDois));

            RCArray.remover(clienteUm.getCpf());

            assertEquals(1, clientesArray.size());
            assertFalse(clientesArray.contains(clienteUm));
            assertTrue(clientesArray.contains(clienteDois));

            assertNotEquals(RCArray.listar().isEmpty(), RCArray.listar());

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testAtualizarClientesArray() {
        try{
            assertDoesNotThrow(() -> RCArray.atualizar(clienteUm));

            assertThrows(ClienteInexistenteException.class, () -> RCArray.atualizar(clienteDois));

            RCArray.inserir(clienteDois);
            assertDoesNotThrow(() -> RCArray.atualizar(clienteDois));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testProcurarClientesArray() {
        try{
            assertDoesNotThrow(() -> RCArray.procurar(clienteUm.getCpf()));

            assertThrows(ClienteInexistenteException.class, () -> RCArray.procurar(clienteDois.getCpf()));

            RCArray.inserir(clienteDois);
            assertDoesNotThrow(() -> RCArray.procurar(clienteDois.getCpf()));

            assertEquals(RCArray.listar().get(1), RCArray.procurar(clienteDois.getCpf()));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testRemoverClientesArray() {
        try{
            assertDoesNotThrow(() -> RCArray.remover(clienteUm.getCpf()));

            assertThrows(ClienteInexistenteException.class, () -> RCArray.remover(clienteDois.getCpf()));

            RCArray.inserir(clienteDois);
            RCArray.inserir(clienteTres);

            assertDoesNotThrow(() -> RCArray.remover(clienteDois.getCpf()));

            assertEquals(RCArray.listar().get(-1), RCArray.procurar(clienteDois.getCpf()));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

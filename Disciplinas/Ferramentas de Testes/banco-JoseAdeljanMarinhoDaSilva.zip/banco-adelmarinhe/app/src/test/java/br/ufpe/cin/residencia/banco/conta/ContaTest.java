package br.ufpe.cin.residencia.banco.conta;

import br.ufpe.cin.residencia.banco.cliente.Cliente;
import br.ufpe.cin.residencia.banco.cliente.TipoCliente;
import br.ufpe.cin.residencia.banco.excecoes.ContaExistenteException;
import br.ufpe.cin.residencia.banco.excecoes.ContaInexistenteException;
import br.ufpe.cin.residencia.banco.excecoes.SaldoInsuficienteException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContaTest {

    CadastroContas RCArray;
    CadastroContas RCMaps;
    ContaAbstrata conta;

    Cliente clienteUm;
    Cliente clienteDois;
    Cliente clienteTres;
    Cliente clienteQuatro;
    Cliente clienteCinco;

    RepositorioContasMap repositorioMap;

    RepositorioContasArray repositorioArray;

    @BeforeEach
    void setUp() {
        RCArray = new CadastroContas(new RepositorioContasArray());
        RCMaps = new CadastroContas(new RepositorioContasMap());
        clienteUm = new Cliente("0000", "Adel", TipoCliente.CLASS);
        clienteDois = new Cliente("0001", "Bruno", TipoCliente.VIP);
        clienteTres = new Cliente("0002", "Trent", TipoCliente.ESPECIAL);
        clienteQuatro = new Cliente("0003", "Junior", TipoCliente.CLASS);
        clienteCinco = new Cliente("0004", "Leopoldo", TipoCliente.ESPECIAL);

        conta = new Conta("000001", clienteUm);
        conta.setSaldo(10000);

        repositorioMap = new RepositorioContasMap();
        repositorioArray = new RepositorioContasArray();
    }

    @Test
    void testCadastrarContaArray() {
        try {
            RCArray.cadastrar(conta);
            assertNotNull(RCArray.procurar(conta.getNumero()));

            Conta contaNova = (Conta) conta;
            assertThrows(ContaExistenteException.class, () -> RCArray.cadastrar(contaNova));

            assertThrows(ContaExistenteException.class, () -> RCArray.cadastrar(conta));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testCadastrarContaMaps() {
        try {
            assertDoesNotThrow(() -> RCMaps.cadastrar(conta));
            ContaAbstrata contaDois = conta;
            assertThrows(ContaExistenteException.class, () -> RCMaps.cadastrar(conta));
            assertThrows(ContaExistenteException.class, () -> RCMaps.cadastrar(contaDois));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testCreditarContaArray() {
        try {
            RCArray.cadastrar(conta);
            conta.setSaldo(1000);

            RCArray.creditar(conta.getNumero(), 500.0);
            assertEquals(1500, conta.getSaldo());

            Conta contaDois = new Conta("000002", 1200, clienteDois);
            assertThrows(ContaInexistenteException.class, () -> RCArray.creditar(contaDois.getNumero(), 100.0));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testDebitarContaArray() {
        try {
            RCArray.cadastrar(conta);
            conta.setSaldo(1000);

            assertDoesNotThrow(() -> RCArray.debitar(conta.getNumero(), 50));

            assertEquals(950, conta.getSaldo());

            assertThrows(SaldoInsuficienteException.class, () -> RCArray.debitar(conta.getNumero(), 20000.0));

            Conta contaDois = new Conta("000002", 1200, clienteDois);
            assertThrows(ContaInexistenteException.class, () -> RCArray.debitar(contaDois.getNumero(), 100.0));

            ContaAbstrata contaTres = new Conta("000003", clienteTres);
            contaTres.setSaldo(1000);
            assertThrows(ContaInexistenteException.class, () -> RCMaps.debitar(contaTres.getNumero(), 100));
            RCArray.cadastrar(contaTres);
            assertDoesNotThrow(() -> RCArray.debitar("000003", 100));
            assertEquals(900, contaTres.getSaldo());
            assertThrows(SaldoInsuficienteException.class, () -> RCArray.debitar(contaTres.getNumero(), 200000));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testTransferirContaArray() {
        try {
            RCArray.cadastrar(conta);
            conta.setSaldo(1000);

            Conta contaDois = new Conta("000002", 1200, clienteDois);
            RCArray.cadastrar(contaDois);

            assertDoesNotThrow(() -> RCArray.transferir(conta.getNumero(), contaDois.getNumero(), 100));

            assertThrows(SaldoInsuficienteException.class, () -> RCArray.transferir(conta.getNumero(), contaDois.getNumero(), 10000));

            double valorAtualConta = conta.getSaldo();
            double transferencia = 10.0;
            conta = RCArray.procurar(conta.getNumero());
            RCArray.transferir(conta.getNumero(), contaDois.getNumero(), transferencia);
            assertEquals(valorAtualConta - transferencia, conta.getSaldo());

            ContaAbstrata contaTres = new Conta("000003", clienteTres);
            assertThrows(ContaInexistenteException.class, () -> RCArray.transferir(contaTres.getNumero(), contaDois.getNumero(), 10000));

            contaTres.setSaldo(1000);
            RCArray.cadastrar(contaTres);

            assertThrows(SaldoInsuficienteException.class, () -> RCArray.transferir(contaTres.getNumero(), contaDois.getNumero(), 10000));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testAtualizarContaArray() {
        try {
            RCArray.cadastrar(conta);

            conta.setCliente(clienteDois);
            assertDoesNotThrow(() -> RCArray.atualizar(conta));

            Conta contaNova = new Conta("000002", 1200, clienteDois);
            assertThrows(ContaInexistenteException.class, () -> RCArray.atualizar(contaNova));

            conta = RCArray.procurar(conta.getNumero());
            assertEquals(clienteDois.getCpf(), conta.getCliente().getCpf());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testAtualizarContaMaps() {
        try {
            RCMaps.cadastrar(conta);

            conta.setCliente(clienteDois);
            assertEquals(clienteDois.getCpf(), conta.getCliente().getCpf());
            assertDoesNotThrow(() -> RCMaps.atualizar(conta));

            assertThrows(ContaInexistenteException.class, () -> RCMaps.atualizar(new Conta("0003", clienteQuatro)));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testProcurarContaArray() {
        try {
            RCArray.cadastrar(conta);

            assertNotNull(RCArray.procurar(conta.getNumero()));

            Conta contaDois = (Conta) RCArray.procurar(conta.getNumero());
            assertEquals("000001", contaDois.getNumero());

            assertThrows(ContaInexistenteException.class, () -> RCArray.procurar("000003"));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testProcurarContaMaps() {
        try {
            RCMaps.cadastrar(conta);
            assertEquals("000001", conta.getNumero());
            assertEquals(conta, RCMaps.procurar(conta.getNumero()));


            Conta contaDois = (Conta) RCMaps.procurar(conta.getNumero());
            assertEquals(contaDois, RCMaps.procurar(contaDois.getNumero()));

            assertDoesNotThrow(() -> RCMaps.procurar("000001"));

            assertThrows(ContaInexistenteException.class, () -> RCMaps.procurar("000003"));

            Conta contaTres = new Conta(null, 1000, clienteTres);
            assertNull(RCMaps.procurar(contaTres.getNumero()));

            Conta contaQuatro = new Conta("0000004", 1000, clienteQuatro);
            assertNull(RCMaps.procurar(contaQuatro.getNumero()));

            RCMaps.cadastrar(contaQuatro);
            assertNotNull(RCMaps.procurar(contaQuatro.getNumero()));

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testRemoverContaArray() {
        try {
            RCArray.cadastrar(conta);
            assertDoesNotThrow(() -> RCArray.remover(conta.getNumero()));

            assertThrows(ContaInexistenteException.class, () -> RCArray.remover("002"));

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testRemoverContaMaps() {
        try {
            RCMaps.cadastrar(conta);
            assertDoesNotThrow(() -> RCMaps.remover(conta.getNumero()));

            assertThrows(ContaInexistenteException.class, () -> RCMaps.remover("002"));

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testContaImposto() {
        try {
            ContaImposto contaImposto = new ContaImposto("0001", clienteTres);
            contaImposto.setSaldo(500);

            contaImposto.creditar(1000);
            assertDoesNotThrow(() -> contaImposto.debitar(700));

            assertEquals(799.3, contaImposto.getSaldo(), 0.01);

            contaImposto.creditar(100);
            assertThrows(SaldoInsuficienteException.class, () -> contaImposto.debitar(1000));

            ContaImposto contaImpostoDois = new ContaImposto("0002", 100, clienteQuatro);

            double TAXA = 0.001;
            double valorDebito = 99.9000999001;

            assertDoesNotThrow(() -> contaImpostoDois.debitar(valorDebito * (1 - TAXA)));
            assertEquals(0.09999999999989484, contaImpostoDois.getSaldo(), 0.01);

            assertThrows(SaldoInsuficienteException.class, () -> contaImpostoDois.debitar(valorDebito));

            assertThrows(SaldoInsuficienteException.class, () -> contaImpostoDois.debitar(valorDebito * (1 + TAXA)));
            assertEquals(0.09999999999989484, contaImpostoDois.getSaldo(), 0.01);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test //100% coverage, killed all mutants
    void testPoupanca() {
        Poupanca poupanca = new Poupanca("0003", clienteQuatro);
        poupanca.setSaldo(1000);

        poupanca.creditar(100);
        poupanca.renderJuros(0.05);

        assertEquals(1155.0, poupanca.getSaldo(), 0.01);

        poupanca.renderJuros(0.05);
        assertEquals(1212.75, poupanca.getSaldo(), 0.01);

        Poupanca poupancaDois = new Poupanca("0001", 1000, clienteQuatro);
        poupancaDois.creditar(-500);
        poupancaDois.renderJuros(0.05);

        assertEquals(525.0, poupancaDois.getSaldo(), 0.01);
    }
    @Test //100% coverage, killed all mutants
    void testContaEspecial() {
        try {
            ContaEspecial contaEspecial = new ContaEspecial("000111", 10000, clienteCinco, 1000);

            RCArray.cadastrar(contaEspecial);
            assertNotNull(RCArray.procurar(contaEspecial.getNumero()));

            assertEquals(11000, contaEspecial.getSaldo());

            ContaEspecial contaEspecialDois = new ContaEspecial("000111", clienteCinco);
            assertNotNull(RCArray.procurar(contaEspecialDois.getNumero()));

            ContaEspecial contaEspecialTres = new ContaEspecial("000111", 10000, clienteCinco);
            assertNotNull(RCArray.procurar(contaEspecialTres.getNumero()));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test //100% coverage, killed all mutants
    void testContaBonificada() {
        try {
            ContaAbstrata contaBonificada = new ContaBonificada("0001", clienteDois);
            contaBonificada.setSaldo(1000);

            RCArray.cadastrar(contaBonificada);
            assertNotNull(RCArray.procurar(contaBonificada.getNumero()));

            ContaBonificada contaBonificadaDois = new ContaBonificada("0002", 100, clienteUm);

            contaBonificadaDois.creditar(100);

            assertEquals(200, contaBonificadaDois.getSaldo());

            contaBonificadaDois.renderBonus();

            contaBonificadaDois.creditar(100);
            assertEquals(301.0, contaBonificadaDois.getSaldo(), 0.01);
            assertEquals(1.0, contaBonificadaDois.getBonus(), 0.01);

            contaBonificadaDois.creditar(100);
            contaBonificadaDois.renderBonus();
            assertEquals(403.0, contaBonificadaDois.getSaldo(), 0.01);
            assertEquals(0.0, contaBonificadaDois.getBonus(), 0.01);

            contaBonificadaDois.creditar(50);
            assertEquals(0.5, contaBonificadaDois.getBonus(), 0.01);

            contaBonificadaDois.creditar(100);
            contaBonificadaDois.creditar(200);
            contaBonificadaDois.creditar(50);
            assertEquals(4.0, contaBonificadaDois.getBonus(), 0.01);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    public void testListar() {
        assertEquals(0, repositorioMap.listar().size());
        assertEquals(100, repositorioArray.listar().size());
    }

    @Test
    void testDebitarContaAbstrata() {
        try {
            ContaAbstrata contaDois = new ContaAbstrata("000002", 1200, clienteDois);
            RCMaps.cadastrar(contaDois);

            assertDoesNotThrow(() -> contaDois.debitar(contaDois.getSaldo() - 1));
            assertEquals(1, contaDois.getSaldo());
            assertDoesNotThrow(() -> contaDois.debitar(contaDois.getSaldo()));
            assertEquals(0, contaDois.getSaldo());

            assertThrows(SaldoInsuficienteException.class, () -> contaDois.debitar(contaDois.getSaldo() + 1));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Test
    void testTransferirContaAbstrata() {
        try {
            RCMaps.cadastrar(conta);
            conta.setSaldo(1000);

            ContaAbstrata contaDois = new ContaAbstrata("000002", 1200, clienteDois);
            double saldoInicial = contaDois.getSaldo();

            assertDoesNotThrow(() -> conta.transferir(contaDois, conta.getSaldo() - 1));
            assertEquals(1, conta.getSaldo());
            assertEquals(2199, contaDois.getSaldo());

            assertDoesNotThrow(() -> conta.transferir(contaDois, conta.getSaldo()));
            assertEquals(0, conta.getSaldo());
            assertEquals(2200, contaDois.getSaldo());

            assertThrows(SaldoInsuficienteException.class, () -> conta.transferir(contaDois,conta.getSaldo() + 1));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

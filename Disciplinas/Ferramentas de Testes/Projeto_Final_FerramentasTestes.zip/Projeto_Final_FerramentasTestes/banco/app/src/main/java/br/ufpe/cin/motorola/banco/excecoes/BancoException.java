package br.ufpe.cin.motorola.banco.excecoes;

public class BancoException extends Exception {
	public BancoException(String msg) {
		super(msg);
	}
}

package br.ufpe.cin.motorola.banco.cliente;

public enum TipoCliente {
	VIP,
	CLASS,
	ESPECIAL;
}
